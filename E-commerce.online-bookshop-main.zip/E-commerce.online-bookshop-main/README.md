Instructions:
1. open cmd and navigate to code directory
2. run main.py
3. enter localhost:5000 in your browser
